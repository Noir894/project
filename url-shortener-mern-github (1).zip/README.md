# URL Shortener (MERN Stack)

A simple URL shortener web app built using the MERN stack (MongoDB, Express.js, React.js, Node.js).

## Features
- Shorten long URLs
- Redirect to original URL when visiting shortened link
- Local MongoDB connection
- Simple React frontend

## Tech Stack
- **Frontend:** React + Vite
- **Backend:** Node.js, Express.js, MongoDB, Mongoose
- **Database:** MongoDB (Local)

## Installation

### Prerequisites
- Node.js installed
- MongoDB installed and running locally

### Backend Setup
```bash
cd backend
npm install
npm run dev
```
Backend will run on **http://localhost:5000**

### Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Frontend will run on **http://localhost:5173**

### MongoDB
Make sure MongoDB is running locally:
```bash
mongod
```

## Folder Structure
```
backend/   → Node.js + Express backend
frontend/  → React frontend
```

## Deployment
- **Frontend:** Vercel / Netlify
- **Backend:** Render / Railway
- **Database:** MongoDB Atlas (for production)
